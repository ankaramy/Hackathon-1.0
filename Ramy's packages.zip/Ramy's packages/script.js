// Load the PNG image
const img = new Image();
img.src = 'icons/ramy8508_achrafieh_lebanon_--v_6.1_f7417123-7992-4655-811d-cec9b0268d92_0 (1).png'; // Replace with your image path

img.onload = () => {
    // Tiling Pattern 1: Simple Grid
    createTiling('canvas1', img, 1, 1); // 3x3 grid

    // Tiling Pattern 2: Larger Tiles
    createTiling('canvas2', img, 5, 5); // 5x5 grid

    // Tiling Pattern 3: Smaller Tiles
    createTiling('canvas3', img, 15, 15); // 15x15 grid

    // Zoomed-in Tiling Pattern for Canvas 4
    createZoomedTiling('canvas4', img, 15, 15, 4); // 15x15 grid with a 4x zoom

    // Duplicate Canvas 4 content to Canvas 5, 6, and 7
    duplicateCanvasContent('canvas4', ['canvas5', 'canvas6', 'canvas7']);
};

// General function to create a tiling pattern
function createTiling(canvasId, image, rows, cols) {
    const canvas = document.getElementById(canvasId);
    const ctx = canvas.getContext('2d');

    // Set canvas size to match the image size
    canvas.width = image.width;
    canvas.height = image.height;

    // Calculate tile size
    const tileWidth = canvas.width / cols;
    const tileHeight = canvas.height / rows;

    // Loop through rows and columns to draw tiles
    for (let row = 0; row < rows; row++) {
        for (let col = 0; col < cols; col++) {
            const sx = col * tileWidth; // Source x (crop start x)
            const sy = row * tileHeight; // Source y (crop start y)

            // Draw the cropped portion of the image on the canvas
            ctx.drawImage(
                image,
                sx, sy, tileWidth, tileHeight, // Source cropping
                col * tileWidth, row * tileHeight, tileWidth, tileHeight // Destination placement
            );

            // Optional: Draw a border for each tile
            ctx.strokeStyle = 'black';
            ctx.lineWidth = 10;
            ctx.strokeRect(
                col * tileWidth + ctx.lineWidth / 2,
                row * tileHeight + ctx.lineWidth / 2,
                tileWidth - ctx.lineWidth,
                tileHeight - ctx.lineWidth
            );
        }
    }
}

// Function to create a zoomed tiling pattern
function createZoomedTiling(canvasId, image, rows, cols, zoomFactor) {
    const canvas = document.getElementById(canvasId);
    const ctx = canvas.getContext('2d');

    // Set canvas size
    canvas.width = image.width;
    canvas.height = image.height;

    // Calculate tile size
    const tileWidth = canvas.width / cols;
    const tileHeight = canvas.height / rows;

    // Calculate zoomed source tile size
    const zoomedTileWidth = (image.width / zoomFactor) / cols;
    const zoomedTileHeight = (image.height / zoomFactor) / rows;

    // Calculate offsets for the zoomed region (centered)
    const offsetX = (image.width - image.width / zoomFactor) / 2;
    const offsetY = (image.height - image.height / zoomFactor) / 2;

    // Loop through rows and columns to draw zoomed tiles
    for (let row = 0; row < rows; row++) {
        for (let col = 0; col < cols; col++) {
            const sx = offsetX + col * zoomedTileWidth; // Adjusted source x
            const sy = offsetY + row * zoomedTileHeight; // Adjusted source y

            // Draw the zoomed and cropped portion of the image
            ctx.drawImage(
                image,
                sx, sy, zoomedTileWidth, zoomedTileHeight, // Source cropping
                col * tileWidth, row * tileHeight, tileWidth, tileHeight // Destination placement
            );

            // Optional: Draw a border for each tile
            ctx.strokeStyle = 'black';
            ctx.lineWidth = 10;
            ctx.strokeRect(
                col * tileWidth + ctx.lineWidth / 2,
                row * tileHeight + ctx.lineWidth / 2,
                tileWidth - ctx.lineWidth,
                tileHeight - ctx.lineWidth
            );
        }
    }
}

// Function to duplicate content from a source canvas to multiple target canvases
function duplicateCanvasContent(sourceCanvasId, targetCanvasIds) {
    const sourceCanvas = document.getElementById(sourceCanvasId);
    const sourceCtx = sourceCanvas.getContext('2d');

    targetCanvasIds.forEach(targetCanvasId => {
        const targetCanvas = document.getElementById(targetCanvasId);
        const targetCtx = targetCanvas.getContext('2d');

        // Match target canvas size to source canvas size
        targetCanvas.width = sourceCanvas.width;
        targetCanvas.height = sourceCanvas.height;

        // Copy the content from source to target
        targetCtx.drawImage(sourceCanvas, 0, 0);
    });
}
